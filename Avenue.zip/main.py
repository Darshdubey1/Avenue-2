import os
from asyncore import loop
import random
import time
import math
from core.Amarok import Amarok
import colorama
from colorama import Fore
import asyncio, json
import jishaku, cogs
from discord.ext import commands, tasks
import discord
from discord import app_commands
import traceback
from discord.ext.commands import Context
from discord import Spotify
import openai
from discord import Embed

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "True"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

client = Amarok()
tree = client.tree
clr = 0x2f3136


async def Amarok_stats():
  while True:
    servers = len(client.guilds)
    users = sum(g.member_count for g in client.guilds
                if g.member_count != None)
    sv_ch = client.get_channel(1104627397380292641)
    users_ch = client.get_channel(1104627683884802049)
    await asyncio.sleep(1000)
    await sv_ch.edit(name="Servers ; {}".format(servers))
    await users_ch.edit(name="Users ; {}".format(users))


class Amarok(discord.ui.Modal, title='Embed Configuration'):
  tit = discord.ui.TextInput(
    label='Embed Title',
    placeholder='Embed title here',
  )

  description = discord.ui.TextInput(
    label='Embed Description',
    style=discord.TextStyle.long,
    placeholder='Embed description optional',
    required=False,
    max_length=5000,
  )

  thumbnail = discord.ui.TextInput(
    label='Embed Thumbnail',
    placeholder='Embed thumbnail here optional',
    required=False,
  )

  img = discord.ui.TextInput(
    label='Embed Image',
    placeholder='Embed image here optional',
    required=False,
  )

  footer = discord.ui.TextInput(
    label='Embed footer',
    placeholder='Embed footer here optional',
    required=False,
  )

  async def on_submit(self, interaction: discord.Interaction):
    embed = discord.Embed(title=self.tit.value,
                          description=self.description.value,
                          color=0x00FFED)
    if not self.thumbnail.value is None:
      embed.set_thumbnail(url=self.thumbnail.value)
    if not self.img.value is None:
      embed.set_image(url=self.img.value)
    if not self.footer.value is None:
      embed.set_footer(text=self.footer.value)
    await interaction.response.send_message(embed=embed)

  async def on_error(self, interaction: discord.Interaction,
                     error: Exception) -> None:
    await interaction.response.send_message('Oops! Something went wrong.',
                                            ephemeral=True)

    traceback.print_tb(error.__traceback__)


@tree.command(name="embed", description="Create A Embed Using Enther")
async def _embed(interaction: discord.Interaction) -> None:
  await interaction.response.send_modal(Amarok())


########################################


@client.listen("on_guild_join")
async def dexterbalak(guild):
  with open('roles.json', 'r') as f:
    pp = json.load(f)
  if guild:
    if not str(guild.id) in pp:
      pp[str(guild.id)] = {"humanautoroles": [], "botautoroles": []}
      with open('role.json', 'w') as f:
        json.dump(pp, f, indent=4)


@client.listen("on_member_join")
async def autorolessacks(member):
  if member.id == client.user.id:
    return
  else:
    gd = member.guild
    with open('roles.json') as f:
      idk = json.load(f)
    g_ = idk.get(str(member.guild.id))
    human_autoroles = g_['humanautoroles']
    bot_autoroles = g_['botautoroles']
    if human_autoroles == []:
      pass
    else:
      for role in human_autoroles:
        rl = gd.get_role(int(role))
        if not member.bot:
          await member.add_roles(rl, reason="Enther Autoroles")
    if bot_autoroles == []:
      pass
    else:
      for rol in bot_autoroles:
        rml = gd.get_role(int(rol))
        if member.bot:
          await member.add_roles(rml, reason="Enther Autoroles")







@client.event
async def on_ready():
  print(Fore.RED + "Loaded & Online!")
  print(Fore.BLUE + f"Logged in as: {client.user}")
  print(Fore.MAGENTA + f"Connected to: {len(client.guilds)} guilds")
  print(Fore.YELLOW + f"Connected to: {len(client.users)} users")
  await client.loop.create_task(Amarok_stats())
  try:
    synced = await client.tree.sync()
    print(f"synced {len(synced)} commands")
  except Exception as e:
    print(e)


from flask import Flask
from threading import Thread

app = Flask(__name__)


@app.route('/')
def home():
  return """I'AM ALIVE"""


def run():
  app.run(host='0.0.0.0', port=8080)


def keep_alive():
  server = Thread(target=run)
  server.start()
  return server


if __name__ == '__main__':
  server = keep_alive()


web=os.getenv("AMAROK")
@client.event
async def on_command_completion(context: Context) -> None:

          full_command_name = context.command.qualified_name
          split = full_command_name.split("\n")
          executed_command = str(split[0])
          void = discord.SyncWebhook.from_url(web)
         # hacker = client.get_channel(1157962854952091818)
          if not context.message.content.startswith("$"):
              pcmd = f"`${context.message.content}`"
          else:
              pcmd = f"`{context.message.content}`"
          if context.guild is not None:
              try:

                  void = discord.Embed(color=0x2f3136)
                  void.set_author(
                      name=
                      f"Executed {executed_command} Command By : {context.author}",
                      icon_url=f"{context.author.avatar}")
                  embed.set_thumbnail(url=f"{context.author.avatar}")
                  void.add_field(
                      name="Command Name :",
                      value=f"{executed_command}",
                      inline=False)
                  void.add_field(
                      name="Command Content :",
                      value="{}".format(pcmd),
                      inline=False)
                  void.add_field(
                      name="Command Executed By :",
                      value=
                      f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                      inline=False)
                  void.add_field(
                      name="Command Executed In :",
                      value=
                      f"{context.guild.name}  | ID: [{context.guild.id}](https://discord.com/users/{context.author.id})",
                      inline=False)
                  void.add_field(
                      name=
                      "Command Executed In Channel :",
                      value=
                      f"{context.channel.name}  | ID: [{context.channel.id}](https://discord.com/channel/{context.channel.id})",
                      inline=False)
                  embed.set_footer(text=f"Thank you for choosing  {client.user.name}",
                                   icon_url=client.user.display_avatar.url)
                  void.send(embed=void)
              except:
                  print('Amarok On Top')
          else:
              try:

                  void1 = discord.Embed(color=0x2f3136)
                  void1.set_author(
                      name=
                      f"Executed {executed_command} Command By : {context.author}",
                      icon_url=f"{context.author.avatar}")
                  embed1.set_thumbnail(url=f"{context.author.avatar}")
                  void1.add_field(
                      name="Command Name :",
                      value=f"{executed_command}",
                      inline=False)
                  void1.add_field(
                      name="Command Executed By :",
                      value=
                      f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                      inline=False)
                  embed1.set_footer(text=f"Thank you for choosing  {client.user.name}",
                                    icon_url=client.user.display_avatar.url)
                  void1.send(embed=void1)
              except:
                  print("xD")
                  



owner_ids = [1180149058296369218, 1147567782217658448]  # Replace with your own owner IDs


@client.command(name='list_guilds')
async def list_guilds(ctx):
  if ctx.message.author.id not in owner_ids:
    await ctx.send("Sorry, only my owner can use this command.")
    return
  guilds = await client.fetch_guilds(limit=None).flatten()
  void = discord.Embed(
    title="List of Guilds",
    description="Here are the guilds that the bot is currently a part of:")
  for guild in guilds:
    invite_link = await guild.text_channels[0].create_invite(max_age=0,
                                                             max_uses=0,
                                                             unique=True)
    embed.add_field(
      name=f"**{guild.name}**",
      value=
      f"**ID**: {guild.id}\n**Members**: {guild.member_count}\n**Invite Link**: {invite_link}",
      inline=False)
    embed.set_footer(text="Guild Command By Enther")
  await ctx.send(embed=void)


@client.event
async def on_command_error(ctx, error):
  if isinstance(error, commands.MissingPermissions):
    await ctx.send(
      f"{ctx.author.mention} You do not have enough permissions to use the `{ctx.command}` command."
    )
  elif isinstance(error, commands.CommandNotFound):
    pass  # do nothing if the command doesn't exist
  else:
    print(f"Error occurred: {str(error)}")




@client.command()
async def spotify(ctx, user: discord.Member = None):
  if user == None:
    user = ctx.author
    pass
  if user.activities:
    for activity in user.activities:
      if isinstance(activity, Spotify):
        nemo = discord.Embed(title=f"{user.name}'s Spotify",
                             description="Listening to {}".format(
                               activity.title),
                             color=0x00FFED)
        nemo.set_thumbnail(url=activity.album_cover_url)
        nemo.add_field(name="Artist", value=activity.artist)
        nemo.add_field(name="Album", value=activity.album)
        nemo.set_footer(text="Song started at {}".format(
          activity.created_at.strftime("%H:%M")))
        await ctx.send(embed=nemo)


async def main():
  async with client:
    os.system("clear")
    await client.load_extension("cogs")
    await client.load_extension("jishaku")
    await client.start(os.getenv("token"))


if __name__ == "__main__":
  asyncio.run(main())
