import discord
from discord.ext import commands

class nsfw1(commands.Cog): #tui or nam e dekhte paros na lol xD
    def __init__(self, bot):
        self.bot = bot

    """Nsfw Commands"""
  
    def help_custom(self):
		      emoji = '<:media:1077917065614217329>'
		      label = "Nsfw"
		      description = "Show You Commands Of Nsfw"
		      return emoji, label, description

    @commands.group()
    async def __Nsfw__(self, ctx: commands.Context):
        """`nsfw` , `nsfw 4k` , `nsfw pussy` , `nsfw boobs` , `nsfw lewd` , `nsfw lesbian` , `nsfw blowjob` , `nsfw cum` , `nsfw gasm` , `nsfw hentai`\n\n**<a:important:1102173582316019752> __Important__**\n**<:dot:1102173666105643088> Only Commands You Can Use Are Displayed !**\n**<:dot:1102173666105643088> If you have Any Question, [Join Our Support Server](https://dsc.gg/visionx-hq)**"""