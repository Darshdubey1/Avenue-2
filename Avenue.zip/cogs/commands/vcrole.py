import discord
from discord.ext import commands
import json
from utils.Tools import *

def reset(guild_id):
  with open("vcroles.json", "r") as f:
    gg = json.load(f)
  gg[str(guild_id)] = {"bots": [], "humans": []}
  with open("vcroles.json", "w") as f:
    json.dump(gg, f, indent=4)

def save(guild_id):
  with open("vcroles.json", "r") as f:
    gg = json.load(f)
  if str(guild_id) in gg:
    return
  gg[str(guild_id)] = {"bots": [], "humans": []}
  with open("vcroles.json", "w") as f:
    json.dump(gg, f, indent=4)

def get_config(guild):
  with open("vcroles.json", "r") as f:
    ok = json.load(f)
  return ok.get(str(guild))

def set_human(guild,role):
  with open("vcroles.json", "r") as f:
    ok = json.load(f)
  ok[str(guild)]["humans"].append(str(role))
  with open("vcroles.json", "w") as f:
    json.dump(ok,f,indent=4)

def del_human(guild,role):
  with open("vcroles.json", "r") as f:
    ok = json.load(f)
  ok[str(guild)]["humans"].remove(str(role))
  with open("vcroles.json", "w") as f:
    json.dump(ok,f,indent=4)

def set_bot(guild,role):
  with open("vcroles.json", "r") as f:
    ok = json.load(f)
  ok[str(guild)]["bots"].append(str(role))
  with open("vcroles.json", "w") as f:
    json.dump(ok,f,indent=4)

def del_bot(guild,role):
  with open("vcroles.json", "r") as f:
    ok = json.load(f)
  ok[str(guild)]["bots"].remove(str(role))
  with open("vcroles.json", "w") as f:
    json.dump(ok,f,indent=4)
  

class Vcroles(commands.Cog):
  def __init__(self, bot):
    self.bot = bot
    self.color = 0x00FFCA

  @commands.Cog.listener()
  async def on_guild_join(self, guild):
    save(guild.id)

  @commands.Cog.listener()
  async def on_ready(self):
    for guild in self.bot.guilds:
      save(guild.id)

  @commands.Cog.listener()
  async def on_voice_state_update(self, member, before, after):
    guild = member.guild
    config=get_config(guild.id)
    if config["bots"] == [] and config["humans"] == []:
      return
    hm = [0]
    br = [0]
    if config["humans"] != []:
      for role in config["humans"]:
        hm.append(guild.get_role(int(role)))
    if config["bots"] != []:
      for role in config["bots"]:
       br.append(guild.get_role(int(role)))
    for role in hm:
      try:
        if after.channel and not before.channel:
          if not member.bot:
            await member.add_roles(role, reason="Amarok VcRoles")
        elif before.channel and not after.channel:
          if not member.bot:
            await member.remove_roles(role, reason="Amarok VcRoles")
      except:
        continue
    for role in br:
      try:
        if after.channel and not before.channel:
          if member.bot:
            await member.add_roles(role, reason="Amarok VcRoles")
        elif before.channel and not after.channel:
          if member.bot:
            await member.remove_roles(role, reason="Amarok VcRoles")
      except:
        continue




      

  @commands.hybrid_group(aliases=["vcroles"], invoke_without_command=True)
  @blacklist_check()
  @ignore_check()
  async def vcrole(self, ctx):
    message = f"""`{ctx.prefix}vcrole config `
Get vcroles config for the server.

`{ctx.prefix}vcrole reset `
Clears vcroles config for the server.

`{ctx.prefix}vcrole bots `
Setup vcroles for bots.

`{ctx.prefix}vcrole humans `
Setup vcroles for human users."""
    embed = discord.Embed(color=self.color, title=f"`{ctx.prefix}vcrole`", description=message)
    await ctx.send(embed=embed)


  @vcrole.command(name="reset",help="Clears all vcroles of server")
  @blacklist_check()
  @ignore_check()
  @commands.has_permissions(administrator=True)
  async def _reset(self,ctx):
    if int(ctx.guild.me.top_role.position) > int(ctx.message.author.top_role.position):
      await ctx.send("<:cross1:1208793725401043036> | You must have role above me to reset vcroles.")
      return
    reset(ctx.guild.id)
    await ctx.send("<:tickmarks:1208766195289821204> | Successfully cleared all vcroles for this server.")
    

  @vcrole.group(name="bots", invoke_without_command=True)
  @blacklist_check()
  @ignore_check()
  async def _bots(self, ctx):
    message = f"""`{ctx.prefix}vcrole bots add <role>`
Add role to list of vcroles for bot users.

`{ctx.prefix}vcrole bots remove <role>`
Remove a role from vcroles for bot users."""
    embed = discord.Embed(color=self.color, title=f"`{ctx.prefix}vcrole bots`", description=message)
    await ctx.send(embed=embed)

    
  @_bots.command(name="add",help="Setup vcroles for bots")
  @blacklist_check()
  @ignore_check()
  @commands.has_permissions(administrator=True)
  async def idkadd(self, ctx, role: discord.Role):
    if int(ctx.guild.me.top_role.position) > int(ctx.message.author.top_role.position):
      await ctx.send("<:cross1:1208793725401043036> | You must have role above me to set vcroles.")
      return
    config = get_config(ctx.guild.id)
    if role.id in config["bots"]:
      await ctx.reply(f"<@&{role.id}> is already in bot vcroles.", allowed_mentions=discord.AllowedMentions(roles=False, everyone=False))
      return
    set_bot(ctx.guild.id, role.id)
    await ctx.send(f"<@&{role.id}> has been added to bot vcroles.")


  @_bots.command(name="remove",help="Removes vcroles for bots")
  @blacklist_check()
  @ignore_check()
  @commands.has_permissions(administrator=True)
  async def idkadd_(self, ctx, role: discord.Role):
    if int(ctx.guild.me.top_role.position) > int(ctx.message.author.top_role.position):
      await ctx.send("<:cross1:1208793725401043036> | You must have role above me to set vcroles.")
      return
    config = get_config(ctx.guild.id)
    if not role.id in config["bots"]:
      await ctx.reply(f"<@&{role.id}> is not in bot vcroles.",allowed_mentions=discord.AllowedMentions(roles=False, everyone=False))
      return
      del_bot(ctx.guild.id, role.id)
    await ctx.send(f"<@&{role.id}> has been removed from bot vcroles.")
    

  @vcrole.group(name="humans", invoke_without_command=True)
  @blacklist_check()
  @ignore_check()
  async def _bots_(self, ctx):
    message = f"""`{ctx.prefix}vcrole humans add <role>`
Add role to list of vcroles for human users.

`{ctx.prefix}vcrole human remove <role>`
Remove a role from vcroles for human users."""
    embed = discord.Embed(color=self.color, title=f"`{ctx.prefix}vcrole humans`", description=message)
    await ctx.send(embed=embed)

    
  @_bots_.command(name="add",help="Setup vcroles for humans")
  @commands.has_permissions(administrator=True)
  @blacklist_check()
  @ignore_check()
  async def idkadd__(self, ctx, role: discord.Role):
    if int(ctx.guild.me.top_role.position) > int(ctx.message.author.top_role.position):
      await ctx.send("<:cross1:1208793725401043036> | You must have role above me to set vcroles.")
      return
    config = get_config(ctx.guild.id)
    if role.id in config["humans"]:
      await ctx.reply(f"<@&{role.id}> is already in human vcroles.",allowed_mentions=discord.AllowedMentions(roles=False, everyone=False))
      return
    set_human(ctx.guild.id, role.id)
    await ctx.send(f"<@&{role.id}> has been added to human vcroles.")


  @_bots_.command(name="remove",help="Removes vcroles for humans")
  @commands.has_permissions(administrator=True)
  @blacklist_check()
  @ignore_check()
  async def _idkadd___(self, ctx, role: discord.Role):
    if int(ctx.guild.me.top_role.position) > int(ctx.message.author.top_role.position):
      await ctx.send("<:cross1:1208793725401043036> | You must have role above me to reset vcroles.")
      return
    config = get_config(ctx.guild.id)
    if not role.id in config["humans"]:
      await ctx.reply(f"<@&{role.id}> is not in human vcroles.",allowed_mentions=discord.AllowedMentions(roles=False, everyone=False))
      return
      del_human(ctx.guild.id, role.id)
    await ctx.send(f"<@&{role.id}> has been removed from human vcroles.")


  @vcrole.command(name="config",help="Config vcroles of server")
  @commands.has_permissions(administrator=True)
  @blacklist_check()
  @ignore_check()
  async def _config(self, ctx):
    config = get_config(ctx.guild.id)
    if config["bots"] == [] and config["humans"] == []:
      return await ctx.send("<:cross1:1208793725401043036> | This server don't have any vcroles setupped.")
    human_ = ""
    bot_ = ""
    if config["bots"] != []:
      for id in config["bots"]:
        bot_+="<@{}>".format(id)
    else:
      bot_+="Not configured."
    if config["humans"] != []:
      for id in config["humans"]:
        human_ += "<@&{}>".format(id)
    else:
      human_+="Not configured."
    embed = discord.Embed(color=self.color, title="Vcroles | Config")
    embed.add_field(name="Human Vc Roles", value=human_)
    embed.add_field(name="Bot Vc Roles", value=bot_)
    embed.set_footer(text=f"Requested by {ctx.message.author}", icon_url=ctx.message.author.avatar)
    await ctx.send(embed=embed)
    
async def setup(bot):
  await bot.add_cog(Vcroles(bot))