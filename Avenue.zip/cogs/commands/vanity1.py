import discord
from discord.ext import commands


class vanity1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Vanityroles Commands"""
  
    def help_custom(self):
		      emoji = '<:amarok_vanity_roles:1208806465490395237>'
		      label = "Vanityroles"
		      description = "Shows Commands of Vanity Roles"
		      return emoji, label, description

    @commands.group()
    async def __Vanityroles__(self, ctx: commands.Context):
        """`vanityroles setup` , `vanityroles show` , `vanityroles reset`"""