import discord
from discord.ext import commands


class welcome1(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Welcome commands"""
  
    def help_custom(self):
		      emoji = '<:amarok_welcome:1208806444015550514>'
		      label = "Welcomer"
		      description = "Show You Commands Of Welcome"
		      return emoji, label, description

    @commands.group()
    async def __Welcomer__(self, ctx: commands.Context):
        """`autorole bots add` , `autorole bots remove` , `autorole bots` , `autorole config` , `autorole humans add` , `autorole humans remove` , `autorole humans` , `autorole reset all` , `autorole reset bots` , `autorole reset humans` , `autorole reset` , `autorole`, `greet autodel` , `greet channel add` , `greet channel remove`, `greet channel` , `greet embed` , `greet image` , `greet message` , `greet ping` , `greet test` , `greet thumbnail` , `greet` \n\n**<a:important:1102173582316019752> __Important__**\n**<:4325335:1092375597235322920> Only Commands You Can Use Are Displayed !**\n**<:4325335:1092375597235322920> If you have Any Question, [Join Our Support Server](https://discord.gg/cydev)**"""