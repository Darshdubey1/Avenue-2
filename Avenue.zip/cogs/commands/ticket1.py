import discord
from discord.ext import commands


class hacker1111111111111111111(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """Ticket commands"""
  
    def help_custom(self):
		      emoji = '<:amarok_ticket:1208806516262576260>'
		      label = "Ticket"
		      description = ""
		      return emoji, label, description

    @commands.group()
    async def __Ticket__(self, ctx: commands.Context):
        """`sendpanel` , `ticket setup`"""